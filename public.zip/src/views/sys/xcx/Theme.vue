<template lang="pug">
Common(type="theme")
</template>

<script setup>
import Common from './component/Common.vue'
</script>

<style lang="less"></style>