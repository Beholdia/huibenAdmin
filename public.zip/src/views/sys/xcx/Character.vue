<template lang="pug">
Common(type="character")

</template>

<script setup>
import Common from './component/Common.vue'

</script>

<style lang="less"></style>