<template lang="pug">
Common(type="brand")

</template>

<script setup>
import Common from './component/Common.vue'

</script>

<style lang="less"></style>